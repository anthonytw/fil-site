# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_fil_global_optspecs
    string join \n L= R= D= A a transport= predict= take-over N config= h/help
end

function __fish_fil_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_fil_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_fil_using_subcommand
    set -l cmd (__fish_fil_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c fil -n "__fish_fil_needs_command" -s L -d 'Listen here, connect from the host: [BIND:]PORT:HOST:HOSTPORT, or PORT for the same port on the host\'s localhost. A bare port binds loopback; * or an empty BIND is every interface. Repeatable' -r
complete -c fil -n "__fish_fil_needs_command" -s R -d 'Listen on the host, connect from here: [BIND:]PORT:HOST:HOSTPORT, or PORT for the same port on this machine\'s localhost (not ssh\'s reverse SOCKS proxy). PORT 0 asks the host for a free port. Repeatable' -r
complete -c fil -n "__fish_fil_needs_command" -s D -d 'A SOCKS proxy here that connects from the host: [BIND:]PORT. Repeatable' -r
complete -c fil -n "__fish_fil_needs_command" -l transport -d 'How to reach the host: auto (the pipe first, then QUIC), pipe (ssh only) or direct (QUIC once attached)' -r -f -a "auto\t''
pipe\t''
direct\t''"
complete -c fil -n "__fish_fil_needs_command" -l predict -d 'Predictive echo for this run, over the config\'s predict setting: off, adaptive (the default: guesses shown only on a slow link) or always' -r -f -a "off\t''
adaptive\t''
always\t''"
complete -c fil -n "__fish_fil_needs_command" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_needs_command" -s A -d 'Relay your ssh-agent to the session while you are attached (the config\'s agent = "confirm" stays "confirm")'
complete -c fil -n "__fish_fil_needs_command" -s a -d 'Do not relay the agent, whatever the config says (the last of -A and -a wins, as in ssh)'
complete -c fil -n "__fish_fil_needs_command" -l take-over -d 'Take the session over without asking when another client is attached to it (the config\'s takeover = "always" for this run). By default fil asks first'
complete -c fil -n "__fish_fil_needs_command" -s N -d 'Tunnel only, as ssh -N: hold the forwards (and the agent relay, with -A) with no terminal, until interrupted. Needs a forward (-L, -R, -D, the config\'s) or -A. The session defaults to "tunnel", not "main", so it never asks to take your shell\'s session. It asks nothing: a session whose holder is disconnected is taken over, a connected holder is left alone (status 1) unless --take-over is given, which an unattended tunnel should'
complete -c fil -n "__fish_fil_needs_command" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_needs_command" -a "ls" -d 'List the sessions on HOST'
complete -c fil -n "__fish_fil_needs_command" -a "kill" -d 'End a session: its shell and everything it started are killed. With --outdated: every session on a daemon older than this fil, after showing them with their jobs and asking'
complete -c fil -n "__fish_fil_needs_command" -a "detach" -d 'Detach whoever is attached to a session; it keeps running (inside a session, with no arguments: this one)'
complete -c fil -n "__fish_fil_needs_command" -a "forward" -d 'Add a forward to a running session, or remove one. The attached client asks its user before it listens or connects for a forward added this way'
complete -c fil -n "__fish_fil_needs_command" -a "ports" -d 'Show what is listening on the host and what is forwarded, with the process behind each'
complete -c fil -n "__fish_fil_needs_command" -a "install" -d 'Install this fil on HOST over ssh, into ~/.local/share/fil (or check what is there, or remove what fil installed)'
complete -c fil -n "__fish_fil_needs_command" -a "config" -d 'Look at the configuration'
complete -c fil -n "__fish_fil_using_subcommand ls" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand ls" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand kill" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand kill" -l outdated -d 'End every session on HOST whose daemon is an older fil than this one (after an upgrade, say a security fix), after listing them with the jobs left in them and asking'
complete -c fil -n "__fish_fil_using_subcommand kill" -s y -l yes -d 'With --outdated: do not ask (needed when stdin is not a terminal)'
complete -c fil -n "__fish_fil_using_subcommand kill" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand detach" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand detach" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand forward" -s L -d 'Add: listen on this machine, connect from the host (same spec as the attach flag)' -r
complete -c fil -n "__fish_fil_using_subcommand forward" -s R -d 'Add: listen on the host, connect from this machine' -r
complete -c fil -n "__fish_fil_using_subcommand forward" -s D -d 'Add: a SOCKS proxy on this machine' -r
complete -c fil -n "__fish_fil_using_subcommand forward" -l rm -d 'Remove the forward that listens on PORT. If a -L and a -R share the port, say which with the flag instead: `--rm -L PORT`' -r
complete -c fil -n "__fish_fil_using_subcommand forward" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand forward" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand ports" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand ports" -l json -d 'Print JSON (schema 1) instead of the table'
complete -c fil -n "__fish_fil_using_subcommand ports" -l probe -d 'Also probe the listeners no fil session started (by default only the -L targets and the sessions\' listeners are). Such a listener is often a tunnel, and the probe reaches whatever it leads to; a known forwarder (ssh, kubectl, ...) is never probed'
complete -c fil -n "__fish_fil_using_subcommand ports" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand install" -l binary -d 'Upload this file instead of the bundled or this fil\'s own binary (it must be a release build for the host)' -r -F
complete -c fil -n "__fish_fil_using_subcommand install" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand install" -l check -d 'Show what is installed on HOST, and the fil on its PATH; change nothing'
complete -c fil -n "__fish_fil_using_subcommand install" -l remove -d 'Remove the copies fil installed on HOST (not one in use by a running daemon)'
complete -c fil -n "__fish_fil_using_subcommand install" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand config; and not __fish_seen_subcommand_from show" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand config; and not __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c fil -n "__fish_fil_using_subcommand config; and not __fish_seen_subcommand_from show" -f -a "show" -d 'Show the settings that apply to HOST and where each value comes from (the default, [defaults] or [host.NAME]), like `ssh -G`. Reads only the config file; never contacts the host'
complete -c fil -n "__fish_fil_using_subcommand config; and __fish_seen_subcommand_from show" -l config -d 'Read this config file instead of ~/.config/fil/config.toml ($FIL_CONFIG also works)' -r -F
complete -c fil -n "__fish_fil_using_subcommand config; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
